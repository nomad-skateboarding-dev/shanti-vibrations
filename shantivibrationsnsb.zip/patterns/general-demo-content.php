<?php
/**
 * Title: Demo content for the theme, and default content for the Home template.
 * Slug: shantivibrationsnsbnsb/general-demo-content
 * Categories: shantivibrationsnsbnsb-general
 */
?>
<!-- wp:pattern {"slug":"shantivibrationsnsbnsb/general-hero-full-height"} /-->

<!-- wp:separator {"backgroundColor":"tertiary","className":"is-style-shantivibrationsnsbnsb-angled-separator-wide"} -->
<hr class="wp-block-separator has-text-color has-tertiary-color has-alpha-channel-opacity has-tertiary-background-color has-background is-style-shantivibrationsnsbnsb-angled-separator-wide"/>
<!-- /wp:separator -->

<!-- wp:pattern {"slug":"shantivibrationsnsbnsb/general-columns-with-paragraphs"} /-->
<!-- wp:pattern {"slug":"shantivibrationsnsbnsb/general-featured-items"} /-->
